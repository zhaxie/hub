import Vue from 'vue'
import vueRouter from 'vue-router'
import index from '@/pages/index'
import goodsDetails from '@/pages/goodsDetails'

Vue.use(vueRouter)
const router = new vueRouter({
    routes: [{
            path: '/',
            name: 'index',
            component: index
        }, {
            path: '/goodsDetails',
            name: 'goodsDetails',
            component: goodsDetails
        }
    ],

})
export default router

