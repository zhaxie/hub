<template>
  <div class="bg-f fixed-bottom p-20 footer-win">
    <!-- 关闭按钮 -->
    <div class="position-absolute z100 close-btn" @click="closeMessWin();"></div>
    <swiper class="h-100" :options="swiperVerContainer">
      <swiper-slide class="p-b-40">
        <!-- 顶部 -->
        <div class="d-flex fw-head">
          <div class="m-r-20 col-auto fh-left-img">
            <img />
          </div>
          <div class="col d-flex flex-column justify-content-between o-hidden m-r-30">
            <p
              class="s16 c-3 text-over-one w-100"
            >云端沙发云端沙端沙发云端端沙发云端发沙云端沙发云端沙端沙发云端端沙发云端发沙沙发云端沙发云端沙端沙发云端端沙发云端发沙沙发云端沙发云端沙端沙发云端端沙发云端发沙沙发沙发</p>
            <p class="s14 c-3">¥2000</p>
            <p>
              <span class="s12 c-6">已选：</span>
              <span class="s12 c-3">200x200x200cm白色</span>
            </p>
          </div>
        </div>
        <!-- 数量 -->
        <div class="m-t-30 m-b-20">
          <p class="m-b-10 s14 c-3">数量</p>
          <ul class="d-flex align-items-center number-box">
            <li class="position-relative reduce-btn nb-item"></li>
            <li class="col text-center nb-item-num">0</li>
            <li class="position-relative puls-btn nb-item"></li>
          </ul>
        </div>
        <!-- 规格详情 -->
        <div
          class="m-t-30 m-b-20"
          v-for="(item, fartherindex) in singnificationList"
          :key="item.id"
        >
          <p class="m-b-10 s14 c-3">{{item.title}}</p>
          <ul class="row align-items-center choose-list">
            <li
              class="item-box"
              :class="item.activeIndex == sonindex ? 'active' : ''"
              v-for="(itemDetailList, sonindex) in item.list"
              :key="itemDetailList.id"
              @click="chooseSingnification"
              :data-fartherindex="fartherindex"
              :data-sonindex="sonindex"
            >
              <div
                class="position-relative m-r-10 m-b-10 text-center s12 c-3 cl-item"
              >{{itemDetailList.title}}</div>
            </li>
          </ul>
        </div>
      </swiper-slide>
    </swiper>
    <!-- 下单按钮 -->
    <p class="fixed-bottom bg-0 s16 c-f text-center buy-btn">下单</p>
  </div>
</template>

<script>
// import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";

export default {
  name: "productMessFooterWin",
  components: {
    swiper,
    swiperSlide
  },
  data() {
    return {
      swiperVerContainer: {
        direction: "vertical",
        slidesPerView: "auto",
        mousewheelControl: true,
        freeMode: true,
        roundLengths: true //防止文字模糊
      },
      singnificationList: [
        {
          id: "0",
          title: "分类0",
          list: [
            {
              id: "00",
              title: "子项0"
            },
            {
              id: "01",
              title: "子项1"
            },
            {
              id: "02",
              title: "子项2"
            },
            {
              id: "03",
              title: "子项3"
            }
          ]
        },
        {
          id: "1",
          title: "分类01",
          list: [
            {
              id: "10",
              title: "子10"
            },
            {
              id: "11",
              title: "子项11"
            },
            {
              id: "12",
              title: "子项12"
            },
            {
              id: "13",
              title: "子项13"
            }
          ]
        }
      ]
    };
  },
  methods: {
    // 关闭弹窗
    closeMessWin: function() {
      this.$emit("toggleProductMessWin", "false");
      this.$store.commit("isShowMask", false);
    },
    // 选择规格
    chooseSingnification: function(e) {
      var _this = this;
      var fartherindex = e.currentTarget.dataset.fartherindex;
      var sonindex = e.currentTarget.dataset.sonindex;

      var curSingnificationList = _this.singnificationList[fartherindex];
      if (curSingnificationList.activeIndex != sonindex) {
        _this.$set(curSingnificationList, "activeIndex", sonindex);
        console.log(curSingnificationList.activeIndex);
      }
    }
  },
  watch: {
    "$store.state.isShowMask"() {
      console.log(this.$store.state.isShowMask);
      this.isShowMessWin = this.$store.state.isShowMask;
    }
  }
};
</script>

<style scoped>
.footer-win {
  height: calc(80vw + 2.5rem);
}
.footer-win .fw-head .fh-left-img {
  width: 5rem;
  height: 5rem;
  background-color: #fbfbfb;
}
.close-btn {
  right: 0.75rem;
  top: 0.9rem;
  width: 1.5rem;
  height: 1.5rem;
  border: 1px solid #000;
}
.close-btn::before,
.close-btn::after {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  margin: auto;
  content: "";
  display: block;
  width: 2px;
  height: 60%;
  border-radius: 2px;
  background-color: #666;
  transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
}
.close-btn::after {
  width: 60%;
  height: 2px;
}
/* 选择数量 */
.number-box {
  width: 6rem;
  border: 1px solid #f4f4f4;
}
.number-box .nb-item {
  width: 1.7rem;
}
.number-box .nb-item-num {
  line-height: 1.7rem;
  border-left: 1px solid #f4f4f4;
  border-right: 1px solid #f4f4f4;
}
.number-box .reduce-btn::before,
.number-box .puls-btn::before,
.number-box .puls-btn::after {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  content: "";
  display: block;
  width: 50%;
  height: 2px;
  background-color: #999;
}
.number-box .puls-btn::after {
  height: 0.85rem;
  width: 2px;
}
/* 详细规格 */
.choose-list {
  margin-right: -0.5rem;
}
.choose-list .item-box {
  min-width: 25%;
}
.choose-list .cl-item {
  line-height: 1.5rem;
  border: 1px solid #f4f4f4;
  padding: 0 0.5rem;
}
.choose-list .active .cl-item {
  border: 1px solid #333;
}
.choose-list .active .cl-item::after {
  position: absolute;
  right: 0rem;
  bottom: 0rem;
  width: 0;
  height: 0;
  content: "";
  display: block;
  border: transparent solid 3px;
  border-right: 3px solid #333;
  border-bottom: 3px solid #333;
}
/* 购买按钮 */
.buy-btn {
  line-height: 2.5rem;
}
>>> .swiper-wrapper {
  height: auto;
}
</style>