<template>
  <transition name="fade">
    <div class="fixed-top mask" v-if="isShowMask" @click="hideMask"></div>
  </transition>
</template>

<script>
export default {
  components: {},
  methods: {
    hideMask(){
        console.log('hide');
        this.$store.state.isShowMask = false;
    }
  },
  computed: {
    isShowMask() {
      console.log(this.$store.state.isShowMask);
      return this.$store.state.isShowMask;
    },
  },
};
</script>

<style scoped>
.mask {
  height: 100%;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 100;
  background-color: rgba(0, 0, 0, 0.3);
}
/* 淡入淡出 */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
  opacity: 1;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>