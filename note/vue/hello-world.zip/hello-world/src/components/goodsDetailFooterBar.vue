<template>
  <div class="fixed-bottom bg-f footer-bar">
    <ul class="row h-100 text-center fb-list">
      <li class="col-2 border">
        <div class="position-absolute iconfont fl-item"></div>
      </li>
      <li class="col-2 border" >
        <div class="position-absolute iconfont fl-item"></div>
      </li>
      <li class="col-4 border" @click="addShopCart">
        <div class="s16 c-0 fl-item-text">加入购物车</div>
      </li>
      <li class="col-4 bg-0" @click="toggleProductMessWin()">
        <div class="s16 c-f fl-item-text">下单{{count}}</div>
      </li>
    </ul>
  </div>
</template>
<script>

export default {
  components: {},
  data() {
    return {};
  },
  methods: {
    toggleProductMessWin: function() {
      this.$emit('toggleProductMessWin', 'true');
      this.$store.commit("isShowMask", true);
    },
    addShopCart: function(){
      this.$store.commit('increment');
      console.log(this.$store.state.count) // -> 1
    },
  },
  computed: {
    count() {
      return this.$store.state.count;
    }
  },
  watch: {
    '$store.state.count'() {
      console.log(this.$store.state.count)
    }
  }
};
</script>

<style scoped>
.footer-bar .fb-list .fl-item {
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  margin: auto;
}
.footer-bar .fb-list .border::before,
.footer-bar .fb-list .border::after {
  position: absolute;
  top: 0;
  content: "";
  display: block;
  background-color: #f4f4f4;
}
.footer-bar .fb-list .border::after {
  right: 0;
  bottom: 0;
  width: 1px;
}
.footer-bar .fb-list .border::before {
  left: 0;
  right: 0;
  height: 1px;
}
.footer-bar .fb-list .fl-item-text {
  line-height: 2.5rem;
}

/* 适配底部固定条 */
@supports (bottom: constant(safe-area-inset-bottom)) or (bottom: env(safe-area-inset-bottom)) {
  .footer-bar {
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
  }
  .footer-bar .fb-list{
    border-bottom: 1px solid #f4f4f4;
  }
}
</style>