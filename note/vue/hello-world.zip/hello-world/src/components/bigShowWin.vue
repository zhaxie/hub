
<template>
  <div class="show-box">
    <!-- 标题 -->
    <p class="row title-list">
      <span class="align-middle col tl-title">新品展示</span>
      <span class="align-middle d-inline-block s14 c-9 tl-number">{{curSlideIndex}}/{{bigShowWinList.length}}</span>
    </p>
    <!-- 列表 -->
    <swiper class="sb-list swiper-img-container" :options="bigShow_swiperOption">
      <swiper-slide class="sl-item" v-for="item in bigShowWinList" :key="item.id">
        <div class="bg-f4 position-relative si-img">
          <img class="position-absolute img-cover" :src="item.img" />
        </div>
        <p class="row justify-content-between align-items-baseline m-t-15 m-b-5 c-0">
          <span class="t16">{{item.title}}</span>
          <span class="s16">¥{{item.price}}</span>
        </p>
        <p class="m-b-5 s12 c-9 lh-z2 text-over-two">{{item.txt}}...</p>
        <symbolList :symbolList="item.symbolList"></symbolList>
      </swiper-slide>
    </swiper>
  </div>
</template>

<script>
import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";
import symbolList from "./symbolList.vue";

export default {
  components: {
    swiper,
    swiperSlide,
    symbolList
  },
  props: ["bannerImgList", "bigShowWinList"],
  data() {
    var _this = this;
    return {
      bigShow_swiperOption: {
        slidesPerView: "auto",
        centeredSlides: true,
        spaceBetween: 10,
        loop: false,
        on: {
          slideChange: function() {
              // console.log(this.activeIndex)
              _this.curSlideIndex = this.activeIndex + 1;
          }
        }
      },
      curSlideIndex: 1,
    };
  },
  methods: {
  }
};
</script>

<style scoped>
/* <!-- 标题 --> */
.title-list {
  margin-top: 2rem;
  padding: 0 1rem 0.75rem 1.5rem;
}
.title-list .tl-title {
  font-size: 1.2rem;
  font-weight: bold;
  color: #000;
}
.tl-number:first-letter {
  font-size: 1.1rem;
  color: #000;
}
/* <!-- 列表 --> */
.sb-list{
    margin-bottom: 2rem;
}
.sb-list .sl-item {
  width: calc(100% - 3rem);
}
.sb-list .sl-item .si-img {
  height: 0;
  padding-bottom: 50%;
}

</style>