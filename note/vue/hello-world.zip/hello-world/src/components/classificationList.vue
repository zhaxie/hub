<template>
    <div class="bg-f4 position-relative o-hidden class-btn-list">
        <ul class="row text-center bt-1-d6 cbl-list">
            <li class="col-3 item" v-for="item in classificationList" :key="item.id">
                <a class="bg-f position-absolute row flex-column justify-content-center align-items-center i-center">
                    <i class="iconfont"></i>
                    <p class="m-t-10 c-0 s14">{{item.title}}</p>
                </a>
            </li>
        </ul>
    </div>
</template>

<script>
    export default {
        components: {},
        props: ["classificationList"],
        data() {
            return {};
        }
    };
</script>

<style scoped>
    .class-btn-list .cbl-list{
        margin-right: -1px;
    }
    .class-btn-list .cbl-list .item::after{
        display: block;
        content: '';
        padding-bottom: 100%;
    }
    .class-btn-list .cbl-list .i-center{
        left:0;
        top: 0;
        right: 1px;
        bottom: 1px;
    }
</style>