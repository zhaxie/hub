<template>
  <swiper class="swiper-img-container" :style="bannerHeight || ''" :options="banner_swiperOption">
    <swiper-slide v-for="item in bannerImgList" :key="item.id" >
        <img class="img-cover" :src="item.imgUrl"/>
    </swiper-slide>
    <div class="swiper-pagination" slot="pagination"></div>
  </swiper>
</template>

<script>
    import "swiper/dist/css/swiper.css";
    import { swiper, swiperSlide } from "vue-awesome-swiper";
    export default {
        components: {
            swiper,
            swiperSlide
        },
        props: ["bannerImgList", "bannerHeight"],
        data() {
            return {
                banner_swiperOption: {
                    slidesPerView: "auto",
                    centeredSlides: true,
                    spaceBetween: 0,
                    speed: 600,             //config参数同swiper4,与官网一致
                    pagination: {
                        el: ".swiper-pagination"
                    }
                },
            };
        },

    };
</script>

<style scoped>
    .swiper-img-container {
        height: 56vw;
    }
    .swiper-img-container .sic-item {
        border: 1px solid #000;
    }
    .swiper-pagination{
        bottom: 0 !important;
    }
    .swiper-pagination >>> .swiper-pagination-bullet-active {
        background: #000 !important;
    }
</style>