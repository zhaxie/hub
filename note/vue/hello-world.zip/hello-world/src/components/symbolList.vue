<template>
  <ul class="row symblo-list">
    <li class="m-r-10 text-center" v-for="item in symbolList" :key="item">
      <span class="sl-item s12" style="color: #c480c0;">{{item}}</span>
    </li>
  </ul>
</template>

<script>
export default { 
  props: ["symbolList"],
  data() {
    return {};
  }
};
</script>

<style scoped>
.symblo-list .sl-item {
  min-width: 3.5rem;
  line-height: 1.8rem;
  padding: 0 0.5rem;
  background-color: #f9eeff;
}
</style>