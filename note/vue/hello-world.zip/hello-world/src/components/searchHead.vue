<template>
  <div class="bg-f search-head-bar">
    <div class="d-flex align-items-center bor-1-d6 h-100">
      <i class="m-h-10 iconfont"></i>
      <input type="text" class="col c-3 s12 h-100" placeholder="搜更多"/>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {};
  }
};
</script>

<style scoped>
    .search-head-bar {
        height: 2.5rem;
        padding: 0.5rem 0.75rem;
    }
</style>