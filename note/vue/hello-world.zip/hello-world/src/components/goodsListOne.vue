<template>
  <div class="bg-f com-bt-20">
    <!-- 标题 -->
    <p class="m-t-40 m-h-30 p-b-15 t24 c-0 bb-1-d6 ">其他展示</p>
    <!-- 商品列表 -->
    <div class="goods-list-box">
      <ul class="row goods-list">
        <li class="col-6 gl-item-box">
          <a class="m-r-10 d-block gl-item">
            <div class="position-relative gi-img">
              <img class="position-absolute img-cover" />
            </div>
            <div class="p-10">
              <p class="t16 c-0 text-over-two">标题名字标题标</p>
              <p class="t16 c-0">￥20.2</p>
            </div>
            <symbolList />
          </a>
        </li>
        <li class="col-6 gl-item-box">
          <a class="m-r-10 d-block gl-item">
            <div class="position-relative gi-img">
              <img class="position-absolute img-cover" />
            </div>
            <div class="p-10">
              <p class="t16 c-0 text-over-two">标题名字标题标</p>
              <p class="t16 c-0">￥20.2</p>
            </div>
            <symbolList />
          </a>
        </li>
        <li class="col-6 gl-item-box">
          <a class="m-r-10 d-block gl-item">
            <div class="position-relative gi-img">
              <img class="position-absolute img-cover" />
            </div>
            <div class="p-10">
              <p class="t16 c-0 text-over-two">标题名字标题标</p>
              <p class="t16 c-0">￥20.2</p>
            </div>
            <symbolList />
          </a>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import symbolList from "./symbolList.vue";

export default {
  components: {
    symbolList
  },
  data() {
    return {};
  }
};
</script>

<style scoped>
/* <!-- 商品列表 --> */
.goods-list-box {
  margin: 0 1.5rem;
  padding-bottom: 1.5rem;
}
.goods-list {
  margin-right: -0.5rem;
}
.goods-list .gl-item-box {
  margin-top: 1.5rem;
}
.goods-list .gl-item-box .gi-img {
  padding-bottom: 100%;
}
</style>