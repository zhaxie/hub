import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);

const store = new Vuex.Store({
    state: {
        count: 0,
        isShowMask: '',
    },
    mutations: {
        increment(state) {
            state.count++
            console.log(state.count++)
        },
        //显示遮罩
        isShowMask(state, isShowMask){
            console.log('vuex.js: ' + isShowMask)
            state.isShowMask = isShowMask;
            // this.$set(this.state, 'isShowMask', isShowMask)
        }
    }
});

export default store