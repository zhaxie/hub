<template>
  <div id="app">
    <transition :name="transitionName">
      <router-view class="Router"></router-view>
    </transition>
  </div>
</template>

<script>
import { constants } from "crypto";
import "@/common/animate.css";

export default {
  name: "app",
  data() {
    return {
      transitionName: ""
    };
  },
  watch: {
    $route(to, from) {
      const toDepth = to.path.split("/").length;
      const fromDepth = from.path.split("/").length;
      if (to.path == "/") {
        this.transitionName = "slide-right";
      } else if (from.path == "/") {
        this.transitionName = "slide-left";
      } else {
        this.transitionName = toDepth < fromDepth ? "slide-right" : "slide-left";
      }
    }
  }
};
</script>

<style scoped>
.Router {
  position: absolute;
  width: 100%;
  transition: all 0.6s ease;
  /* transition: all 4s ease; */
}

.slide-left-enter,
.slide-right-leave-active {
  -webkit-transform: translate3d(100%, 0, 0);
  transform: translate3d(100%, 0, 0);
}
.slide-right-enter,
.slide-left-leave-active{
  -webkit-transform: translate3d(-50%, 0, 0);
  transform: translate3d(-50%, 0, 0);
}
</style>