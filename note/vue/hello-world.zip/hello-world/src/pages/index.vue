<template>
  <div class="bg-f" id="index">
    <searchHead />
    <router-link to="/goodsDetails">
      <swiper :bannerImgList="bannerImgList" />
    </router-link>
    <classificationList :classificationList="classificationList" />
    <div class="com-bt-20 bg-f" style="padding-bottom: 1px;">
      <bigShowWin :bigShowWinList="bigShowWinList" />
      <bigShowWin :bigShowWinList="bigShowWinList" />
    </div>
    <goodsListOne />
  </div>
</template>

<script>
import searchHead from "@/components/searchHead.vue";
import swiper from "@/components/swiper.vue";
import classificationList from "@/components/classificationList.vue";
import bigShowWin from "@/components/bigShowWin.vue";
import goodsListOne from "@/components/goodsListOne.vue";

export default {
  name: "index",
  components: {
    searchHead,
    swiper,
    classificationList,
    bigShowWin,
    goodsListOne
  },
  data: function() {
    return {
      bannerImgList: [
        {
          id: "0",
          imgUrl:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg"
        },
        {
          id: "1",
          imgUrl:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg"
        },
        {
          id: "2",
          imgUrl:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg"
        }
      ],
      classificationList: [
        {
          id: "00",
          title: "分类名字0"
        },
        {
          id: "01",
          title: "分类名字01"
        },
        {
          id: "02",
          title: "分类名字02"
        },
        {
          id: "03",
          title: "分类名字03"
        },
        {
          id: "04",
          title: "分类名字04"
        },
        {
          id: "05",
          title: "分类名字05"
        }
      ],
      bigShowWinList: [
        {
          id: 0,
          img:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg",
          title: "标题0",
          price: "10",
          txt:
            "超矿大，极致舒超矿大，极致舒，超矿大，，极致舒适极致舒适，极致舒超矿大，极矿大极适...",
          symbolList: ["特点0", "特点0", "特点0"]
        },
        {
          id: 1,
          img:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg",
          title: "标题0",
          price: "10",
          txt:
            "超矿大，极致舒超矿大，极致舒，超矿大，，极致舒适极致舒适，极致舒超矿大，极矿大极适...",
          symbolList: ["特点0", "特点0", "特点0"]
        },
        {
          id: 2,
          img:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg",
          title: "标题0",
          price: "10",
          txt:
            "超矿大，极致舒超矿大，极致舒，超矿大，，极致舒适极致舒适，极致舒超矿大，极矿大极适...",
          symbolList: ["特点0", "特点0", "特点0"]
        }
      ]
    };
  }
};
</script>