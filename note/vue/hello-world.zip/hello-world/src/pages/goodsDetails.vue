<template>
  <div class="mh-100vh bg-f pageStyle">
    <!-- 轮播图 -->
    <swiper :bannerImgList="bannerImgList" :bannerHeight="bannerHeight" />
    <!-- 商品底部栏 -->
    <goodsDetailFooterBar @toggleProductMessWin="toggleProductMessWin" />
    <!-- 底部弹出框 -->
    <transition name="slideUp">
      <productMessFooterWin @toggleProductMessWin="toggleProductMessWin" v-if="isShowMessWin" />
    </transition>
    <!-- 遮罩 -->
    <maskBg />
  </div>
</template>

<script>
import swiper from "@/components/swiper.vue";
import goodsDetailFooterBar from "@/components/goodsDetailFooterBar.vue";
import productMessFooterWin from "@/components/productMessFooterWin.vue";
import maskBg from "@/components/mask.vue";

export default {
  components: {
    swiper,
    goodsDetailFooterBar,
    productMessFooterWin,
    maskBg
  },
  data() {
    return {
      isShowMessWin: false,
      bannerImgList: [
        {
          id: "0",
          imgUrl:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg"
        },
        {
          id: "1",
          imgUrl:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg"
        },
        {
          id: "2",
          imgUrl:
            "http://img0.imgtn.bdimg.com/it/u=3035133617,4161315515&fm=11&gp=0.jpg"
        }
      ],
      bannerHeight: "height: 80vw;"
    };
  },
  methods: {
    toggleProductMessWin: function(isShow) {
      console.log('isShow: ' + isShow);
      var _this = this;
      if (isShow == "true") {
        _this.isShowMessWin = true;
        // this.$store.commit("isShowMask", true);
      } else {
        _this.isShowMessWin = false;
      }
    }
  },
  watch: {
    '$store.state.isShowMask'() {
      console.log(this.$store.state.isShowMask)
      this.isShowMessWin = this.$store.state.isShowMask
    }
  }
};
</script>

<style scoped>
.slideUp-enter-active,
.slideUp-leave-active {
  transition: transform 0.5s;
  transform: translate3d(0, 0, 0);
}
.slideUp-enter,
.slideUp-leave-to {
  transform: translate3d(0, 100%, 0);
}
</style>